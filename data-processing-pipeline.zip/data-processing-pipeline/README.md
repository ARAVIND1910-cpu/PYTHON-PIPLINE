# Data Processing Pipeline

A Python data processing pipeline that reads raw data from CSV/JSON files, cleans and transforms it, handles missing values and type conversions, removes duplicates, validates records, logs each processing stage, and writes structured output.

## Features
- CSV and JSON input support
- Missing-value handling
- Type conversion and validation
- Duplicate removal
- Data normalization
- Configurable processing using `config.json`
- Logging to console and `pipeline.log`
- Structured CSV and JSON output
- Simple command-line interface
- Unit tests

## Project Structure
```text
data-processing-pipeline/
├── data/
│   ├── input.csv
│   └── input.json
├── output/
├── src/
│   └── pipeline.py
├── tests/
│   └── test_pipeline.py
├── config.json
├── requirements.txt
└── README.md
```

## Setup

Python 3.9+ is recommended.

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Linux/macOS:
```bash
source .venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

## Run

CSV:
```bash
python src/pipeline.py --input data/input.csv --output output/processed.csv --format csv
```

JSON:
```bash
python src/pipeline.py --input data/input.json --output output/processed.json --format json
```

If `--format` is omitted, it is inferred from the file extension.

## Processing Steps
1. Read raw CSV/JSON data
2. Normalize column names
3. Convert data types
4. Fill missing values using configuration
5. Remove duplicate records
6. Validate records
7. Transform values
8. Save structured output
9. Generate processing logs

## Example Output

```text
id,name,age,city,score
101,Arun,21,chennai,87.5
102,Meena,20,madurai,91.0
103,Ravi,22,coimbatore,78.0
```

## Configuration

Edit `config.json` to change defaults without changing Python code.

## Testing

```bash
python -m unittest discover tests
```

## GitHub Submission

Push this project to a public GitHub repository and submit the repository URL in the assignment form.
